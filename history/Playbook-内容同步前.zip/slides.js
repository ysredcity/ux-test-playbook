(()=>{
const art=window.UX_ART,pages=window.UX_OUTLINE_PAGES;
const esc=t=>t.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const cover=`<div class="editorial-cover-top"><span>体验观察<br><i>UX Evaluation</i></span><span>设计规范 × 新差旅评测<br>26 PAGES / 24 PRINCIPLES</span></div><div class="editorial-cover-main"><div class="cover-title"><p class="cover-eyebrow">THE EXPERIENCE ENGINEER’S PERSPECTIVE</p><h1>体验工程师<br>如何判断<br><em>一个界面是否合理</em><span class="blue-cursor" aria-hidden="true"></span></h1></div><div class="cover-margin"><p>从操作中的心理感受，<br>追溯界面背后的设计原因。</p><button class="start" data-go="2">进入第一章 ${art.arrow}</button></div></div><div class="editorial-cover-bottom"><span>观察现象 → 理解感受 → 回查依据</span><span>01—04 · 用户体验评测</span></div>`;
function supporting(p){
 if(p.extra==='approval')return `<div class="case-instrument"><div class="bot-message"><span class="bot-avatar">审</span><div><b>审批机器人</b><p>${art.check} 你已通过这项申请</p></div></div><span class="relation-label">返回之前打开的页面 ↓</span>${art.approval(false)}</div><p class="caption">差旅案例 #12 / #13 重绘 · 非原产品截图</p>`;
 if(p.extra.startsWith('signal:')){const n=+p.extra.split(':')[1];return `<div class="case-instrument signal-instrument">${art.signal(n)}</div><p class="caption">根据差旅案例重绘 · 非原产品截图</p>`}
 return '';
}
window.UX_SLIDES=pages.map(p=>{const ruleCount=p.kind==='rules'?(p.body.match(/class="original-rule"/g)||[]).length:0;const treatment=ruleCount>=4?' rules-many':ruleCount===1?' rule-solo':'';return {...p,cls:'editorial-page outline-'+p.kind+treatment,body:p.kind==='cover'?cover:p.body}});
document.getElementById('deck').innerHTML=window.UX_SLIDES.map((p,i)=>{
 if(p.kind==='cover')return `<article class="page cover" id="p1" data-page="1" aria-label="封面"><div class="page-inner">${cover}</div></article>`;
 const colon=p.title.indexOf('：'),displayTitle=colon>=0?`<span class="title-prefix">${esc(p.title.slice(0,colon+1))}</span><wbr>${esc(p.title.slice(colon+1))}`:esc(p.title);
 const illustration=supporting(p),part=p.kind==='table'?`整表 · ${p.tables[0].rows.length} 行`:p.parts>1?`${p.part} / ${p.parts}`:'';
 let body=p.body;
 if(p.kind==='path'||p.kind==='path-table')body=body.replace(/<p data-block="([^"]+)"><strong>([^<]+ → [^<]+)<\/strong><\/p>/,(match,id,text)=>`<ol class="original-path" data-block="${id}">${text.split(' → ').map(t=>`<li>${t}</li>`).join('')}</ol>`);
 if(p.kind==='rules')body=body.replace(/<h3>(\d+)\. (.*?)<\/h3>/g,(m,n,t)=>`<h3><span class="rule-number">${n}.</span><span>${t}</span></h3>`);
 const extra=p.extra==='form-demo'?'<button class="text-button" data-demo>体验表单校验 ↗</button>':p.extra==='rule-index'?'<button class="text-button" data-rule="">搜索24条规范 ↗</button>':'';
 return `<article class="page ${p.cls}" id="p${i+1}" tabindex="-1" data-page="${i+1}" data-section="${esc(p.section)}" aria-label="第${i+1}页：${esc(p.title)}"><div class="page-inner"><div class="page-heading"><div class="heading-meta">${p.section?`<p class="outline-chapter">${esc(p.chapter)}</p>`:'<span></span>'}${part?`<span class="part-count">${part}</span>`:''}</div><h2>${displayTitle}</h2></div><div class="outline-layout ${illustration?'with-illustration':''}">${illustration?`<aside class="outline-illustration">${illustration}</aside>`:''}<div class="outline-content">${body}</div></div>${extra}</div></article>`;
}).join('');
})();
